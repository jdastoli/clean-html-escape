const sanitizeHtml = require('sanitize-html');
const defaultConfig = require('./config/default.json');

/**
 * sanitize(html, config?)
 * - html: string
 * - config: object following sanitize-html options (optional)
 *
 * returns { sanitized: string, removed: { tags: {tag: count}, attributes: {attr: count} } }
 */
function sanitize(html, config) {
  const cfg = config ? mergeConfig(defaultConfig, config) : defaultConfig;

  const removed = { tags: {}, attributes: {} };

  // wrap transformTags to remove inline event handlers and javascript: URIs
  const baseTransform = cfg.transformTags || {};
  const trackingTransform = {
    '*': function (tagName, attribs) {
      const cleanedAttribs = {};
      for (const [k, v] of Object.entries(attribs || {})) {
        if (/^on/i.test(k)) {
          removed.attributes[k] = (removed.attributes[k] || 0) + 1;
          continue;
        }
        if (typeof v === 'string' && v.trim().toLowerCase().startsWith('javascript:')) {
          removed.attributes[k] = (removed.attributes[k] || 0) + 1;
          continue;
        }
        cleanedAttribs[k] = v;
      }
      return { tagName, attribs: cleanedAttribs };
    }
  };

  const mergedTransform = { ...trackingTransform, ...baseTransform };

  const result = sanitizeHtml(html, {
    ...cfg,
    transformTags: mergedTransform,
    allowedStyles: cfg.allowedStyles || {}
  });

  // Approximate tag removals by counting tags present in original vs sanitized
  const originalTags = (html.match(/<\s*([a-zA-Z0-9\-]+)/g) || []).map(m => m.replace(/<\s*/, '').toLowerCase());
  const sanitizedTags = (result.match(/<\s*([a-zA-Z0-9\-]+)/g) || []).map(m => m.replace(/<\s*/, '').toLowerCase());

  const origCounts = {};
  const sanCounts = {};
  for (const t of originalTags) origCounts[t] = (origCounts[t] || 0) + 1;
  for (const t of sanitizedTags) sanCounts[t] = (sanCounts[t] || 0) + 1;

  for (const [t, c] of Object.entries(origCounts)) {
    const san = sanCounts[t] || 0;
    if (c > san) removed.tags[t] = c - san;
  }

  return { sanitized: result, removed };
}

function mergeConfig(defaultCfg, customCfg) {
  const merged = JSON.parse(JSON.stringify(defaultCfg)); // deep clone
  for (const k of Object.keys(customCfg)) {
    if (Array.isArray(customCfg[k]) || typeof customCfg[k] !== 'object' || customCfg[k] === null) {
      merged[k] = customCfg[k];
    } else {
      merged[k] = { ...(merged[k] || {}), ...customCfg[k] };
    }
  }
  return merged;
}

module.exports = { sanitize };