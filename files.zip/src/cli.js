#!/usr/bin/env node
const fs = require('fs-extra');
const path = require('path');
const yargs = require('yargs/yargs');
const { hideBin } = require('yargs/helpers');
const { sanitize } = require('./sanitizer');

const argv = yargs(hideBin(process.argv))
  .usage('Usage: $0 [options] [file]')
  .option('o', {
    alias: 'output',
    describe: 'Write sanitized HTML to this file (default stdout)',
    type: 'string'
  })
  .option('c', {
    alias: 'config',
    describe: 'Path to JSON config file (defaults to built-in)',
    type: 'string'
  })
  .option('i', {
    alias: 'inplace',
    describe: 'Sanitize input file in place (overwrites input)',
    type: 'boolean'
  })
  .option('d', {
    alias: 'dry-run',
    describe: 'Do not write output; print a diff-like summary to stdout',
    type: 'boolean'
  })
  .option('v', {
    alias: 'verbose',
    describe: 'Verbose output',
    type: 'boolean'
  })
  .example('$0 index.html -o index.sanitized.html', 'Sanitize file to a new file')
  .example('cat file.html | $0 - -o sanitized.html', 'Sanitize from stdin (use - as file)')
  .help('h')
  .alias('h', 'help')
  .parse();

async function readStdin() {
  return new Promise((resolve, reject) => {
    let data = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', chunk => (data += chunk));
    process.stdin.on('end', () => resolve(data));
    process.stdin.on('error', reject);
  });
}

(async () => {
  try {
    let input = '';
    const fileArg = argv._[0];

    if (!fileArg || fileArg === '-') {
      // read from stdin
      if (process.stdin.isTTY) {
        console.error('No input provided. Provide a file path or pipe HTML to stdin.');
        process.exit(2);
      }
      input = await readStdin();
    } else {
      input = await fs.readFile(path.resolve(fileArg), 'utf8');
    }

    const configPath = argv.config ? path.resolve(argv.config) : null;
    const config = configPath && (await fs.pathExists(configPath))
      ? await fs.readJSON(configPath)
      : null;

    const { sanitized, removed } = sanitize(input, config || undefined);

    if (argv['dry-run']) {
      // Print a small summary / diff-like view
      console.log('--- original vs sanitized summary ---');
      console.log(`Original length: ${input.length}`);
      console.log(`Sanitized length: ${sanitized.length}`);
      console.log('Removed elements/attributes summary (counts):');
      console.log(JSON.stringify(removed, null, 2));
      process.exit(0);
    }

    if (argv.inplace && fileArg && fileArg !== '-') {
      await fs.writeFile(path.resolve(fileArg), sanitized, 'utf8');
      if (argv.verbose) console.log(`Sanitized and overwrote ${fileArg}`);
      else console.log(`Sanitized ${fileArg}`);
      process.exit(0);
    }

    if (argv.output) {
      const outPath = path.resolve(argv.output);
      await fs.outputFile(outPath, sanitized, 'utf8');
      if (argv.verbose) console.log(`Sanitized output written to ${outPath}`);
      else console.log(`Wrote sanitized output to ${outPath}`);
      process.exit(0);
    }

    // default: write to stdout
    process.stdout.write(sanitized);
  } catch (err) {
    console.error('Error:', err.message || err);
    process.exit(1);
  }
})();