```markdown
# html-sanitize

A small Node.js CLI + library to sanitize HTML using a configurable allowlist.

Features
- CLI: sanitize files or stdin, write to stdout or file, or in-place replacement.
- Library: import `sanitize(html, config?)` to reuse sanitization logic in other apps.
- Default config prevents common XSS vectors: strips `<script>`, inline event handlers, `javascript:` URIs, and unsafe attributes.
- Dry-run mode shows a short summary of removals.
- Configurable via JSON file for custom tag/attribute allowlists.

Quick start
1. Clone or create repository and paste files.
2. Install dependencies:
   npm install

3. Run tests:
   npm test

CLI usage
- Sanitize a file and print to stdout:
  node ./src/cli.js path/to/input.html

- Sanitize and write to a new file:
  node ./src/cli.js path/to/input.html -o path/to/output.html

- Sanitize in-place (overwrite):
  node ./src/cli.js path/to/input.html -i

- Sanitize from stdin:
  cat some.html | node ./src/cli.js -

- Use a custom config:
  node ./src/cli.js input.html -c path/to/config.json -o out.html

Library usage
const { sanitize } = require('./src/sanitizer');
const { sanitized, removed } = sanitize('<img src="x" onerror="alert(1)">');

- sanitized: sanitized HTML string
- removed: summary object with counts of removed tags and attributes

Default config
The project includes `src/config/default.json`. It keeps common content tags while removing script/style and inline event handlers by default.

Security notes
- Use an allowlist approach; be conservative with allowed tags/attributes.
- `data:` URIs are allowed for images by default but consider disabling for stricter contexts.
- If you allow `style` attributes or `<style>` tags, sanitize CSS contents as well.

Extending
- Add configuration presets for different contexts (email, comments, WYSIWYG).
- Add batch/recursive directory processing and streaming support.
- Add richer reporting (structured diffs, node-level removals).

License
MIT
```