const fs = require('fs');
const path = require('path');
const { sanitize } = require('../src/sanitizer');

test('removes script tags and unsafe attributes', () => {
  const html = fs.readFileSync(path.join(__dirname, 'sample.html'), 'utf8');
  const { sanitized, removed } = sanitize(html);
  expect(sanitized).not.toMatch(/<script/i);
  expect(sanitized).not.toMatch(/javascript:alert/);
  expect(sanitized).not.toMatch(/onerror=/i);
  expect(sanitized).not.toMatch(/onclick=/i);
  // ensure tags like img/a get preserved (but cleaned)
  expect(sanitized).toMatch(/<img/i);
  expect(sanitized).toMatch(/<a/i);
});